
/**
 * @method localStorageInit
 * @param {String} arg0
 */
ca.localStorageInit = function (
fullpath
)
{
    
};

/**
 * @method localStorageGetItem
 */
ca.localStorageFree = function (
)
{
    
};

/**
 * @method localStorageGetItem
 * @param {String} arg0
 * @param {String} arg1
 */
ca.localStorageSetItem = function (
key,
value
)
{
    
};

/**
 * @method localStorageGetItem
 * @param {String} arg0
 * @return {String}
 */
ca.localStorageGetItem = function (
key
)
{
    return "";
};

/**
 * @method localStorageGetItem
 * @param {String} arg0
 */
ca.localStorageRemoveItem = function (
key
)
{
    
};


/**
 * @class CAMotionManager
 */
ca.CAMotionManager = {

/**
 * @method stopGyroscope
 */
startGyroscope : function (
func
)
{
},

};


/**
 * @class CADatePickerView
 */
ca.CADatePickerView = {

/**
* @method stopGyroscope
*/
onSelectRow : function (
func
)
{
},

};


/**
 * @class CADatePickerView
 */
ca.CADownloadManager = {

/**
* @method stopGyroscope
*/
setDownloadManagerDelegate : function (
delegate
)
{
},

};

/**
 * @class CANotificationCenter
 */
ca.CANotificationCenter = {
/**
* @method removeObserver
* @param {func} arg0
* @param {ca.CAObject} arg1
* @param {String} arg2
*/
addObserver : function (
func,
caobject,
str
)
{
},
};




